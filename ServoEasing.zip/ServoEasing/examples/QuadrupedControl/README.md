# Quadruped / mePed V2 example
[![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)

Youtube video of mePed in action controlled by an IR remote

[![mePed V2 in actions](https://i.ytimg.com/vi/cLgj_sr7f1o/hqdefault.jpg)](https://youtu.be/cLgj_sr7f1o)

Servo movements ar controlled by the Servo easing library for Arduino.
For lifting the legs, the lift servos just use the easing type EASE_QUADRATIC_BOUNCING.
